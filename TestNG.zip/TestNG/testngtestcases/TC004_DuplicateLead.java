package testngtestcases;

import org.testng.annotations.Test;

public class TC004_DuplicateLead extends ProjectSpecificMethods{
	@Test
	public void duplicateLead() throws InterruptedException {
	// Click on Login Button
		
			driver.findElementByClassName("decorativeSubmit").click();
			// Click on crm/sfa button
			driver.findElementByLinkText("CRM/SFA").click();
			// Click on Leads
			driver.findElementByLinkText("Leads").click();
			//Click Find leads
			driver.findElementByLinkText("Find Leads").click();
			//Click on Email
			driver.findElementByXPath("//span[text()='Email']").click();
			driver.findElementByName("emailAddress").sendKeys("vigneshkandiah@gmail.com");
			driver.findElementByXPath("//button[text()='Find Leads']").click();
			//capture name of first resuting lead
			Thread.sleep(2000);
			System.out.println(driver.findElementByXPath(("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]")).getText());
			String fname= driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
			//Click First Resulting lead
			driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").click();
			//Click Duplicate Lead
			driver.findElementByLinkText("Duplicate Lead").click();
			//verify title as duplicate lead

			String title = driver.findElementByXPath("//div[@class='x-panel-header sectionHeaderTitle']").getText();
			System.out.println("verifying duplcate lead title is present"+title);
			//Click Create Lead
			driver.findElementByClassName("smallSubmit").click();
			//Verify captured name and duplicate are same
			String duplicatName=driver.findElementById("viewLead_firstName_sp").getText();
			System.out.println("Duplicate name is"+duplicatName);
			if(fname.equals(duplicatName))
			{
				System.out.println("duplicate lead name is same as captured lead");
			}
				else
				{
					System.out.println("duplicate lead name is not same as captured lead");
				}
					
			}
			 
	
}
