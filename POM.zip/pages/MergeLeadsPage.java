package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import base.ProjectSpecificMethods;

public class MergeLeadsPage extends ProjectSpecificMethods {

	public FindLeadsWindow clickOnIconNearFromLead()
	{
		driver.findElementByXPath("//img[@src='/images/fieldlookup.gif']").click();
		
		return new FindLeadsWindow();
	}
	public FindLeadsWindow clickOnIconNearToLead()
	{
		driver.findElementByXPath("(//img[@src='/images/fieldlookup.gif'])[2]").click();
		
		return new FindLeadsWindow();
	}
	public ViewLeadPage clickMergeInMergeLeadsPage()
	{
		driver.findElementByLinkText("Merge").click();
		driver.switchTo().alert().accept();
		return new ViewLeadPage();
	}
	
}
