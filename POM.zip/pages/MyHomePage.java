package pages;

import base.ProjectSpecificMethods;


public class MyHomePage extends ProjectSpecificMethods{
	public MyLeads clickLeads()
	{
		driver.findElementByLinkText("Leads").click();
		return new MyLeads();
	}

}
