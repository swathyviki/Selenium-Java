package pages;

import base.ProjectSpecificMethods;

public class EditLeadPage extends ProjectSpecificMethods {

	public EditLeadPage changeCompanyName() {
		driver.findElementById("updateLeadForm_companyName").clear();
		driver.findElementById("updateLeadForm_companyName").sendKeys("ADP");
		return this;
	}
	public ViewLeadPage clickUpdate()
	{
		driver.findElementByXPath("//input[@value='Update']").click();
		return new ViewLeadPage();
		
	}
}

