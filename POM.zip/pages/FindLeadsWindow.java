package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import base.ProjectSpecificMethods;

public class FindLeadsWindow extends ProjectSpecificMethods{
	
	public FindLeadsWindow enterLeadIdinFindLeadsWindow(String fromid)
	{
		//Move to new window
				Set<String> wdw1=driver.getWindowHandles();
				List<String> lstwindowHandles= new ArrayList<String>(wdw1);
				String secondwindow=lstwindowHandles.get(1);
				driver.switchTo().window(secondwindow);
				//Enter Lead Id
				driver.findElementByXPath("//input[@type='text']").sendKeys(fromid);
				return this;
	}
	public MergeLeadsPage clickFirstResultingLeadId() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		//Switch back to primary window
		Set<String> wdw1=driver.getWindowHandles();
		List<String> lstwindowHandles= new ArrayList<String>(wdw1);
		driver.switchTo().window(lstwindowHandles.get(0));
		return new MergeLeadsPage();
	}
	public FindLeadsWindow clickFindLeadsButtonInFindLeadsWindow() throws InterruptedException
	{
		//Click Find Leads button
				Thread.sleep(2000);
				driver.findElementByXPath("//button[@class='x-btn-text']").click();
				return this;
	}public MergeLeadsPage clickFirstResultingLeadIdInFindLeadsWindow() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		//Switch back to primary window
		Set<String> wdw1=driver.getWindowHandles();
		List<String> lstwindowHandles= new ArrayList<String>(wdw1);
		driver.switchTo().window(lstwindowHandles.get(0));
		return new MergeLeadsPage();
	}
	
}
