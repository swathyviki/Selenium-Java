package pages;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{

	public CreateLeadPage enterCompanyName(String cname)
	{
		driver.findElementById("createLeadForm_companyName").sendKeys(cname);
		return this;
	}
	public CreateLeadPage enterFirstName(String fname)
	{
		driver.findElementById("createLeadForm_firstName").sendKeys(fname);
		return this;
	}
	public CreateLeadPage enterLastName(String lname)
	{
		driver.findElementById("createLeadForm_lastName").sendKeys(lname);
		return this;
	}
	public ViewLeadPage clickCreateLead()
	{
		driver.findElementByClassName("smallSubmit").click();
		return new ViewLeadPage();
	}
}
