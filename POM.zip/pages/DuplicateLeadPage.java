package pages;

import base.ProjectSpecificMethods;

public class DuplicateLeadPage extends ProjectSpecificMethods{
public DuplicateLeadPage verifyPageTitleidDuplicateLead()
{
	String title = driver.findElementByXPath("//div[@class='x-panel-header sectionHeaderTitle']").getText();
	System.out.println("verifying duplcate lead title is present"+title);
	return this;
}
public ViewLeadPage clickCreateLeadinDuplicateLeadPage()
{
	driver.findElementByClassName("smallSubmit").click();
	return new ViewLeadPage();
}
}
