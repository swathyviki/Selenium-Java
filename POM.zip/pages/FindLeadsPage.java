package pages;

import base.ProjectSpecificMethods;

public class FindLeadsPage extends ProjectSpecificMethods{
	
	public FindLeadsPage enterFirstNameinFindLeadsPage()
	{
		driver.findElementByXPath("(//div[@class='x-form-element']/input[@name='firstName'])[3]").sendKeys("Swathy");
		return this;
	}
	public FindLeadsPage enterLeadIdinFindLeadsPage(String leadid)
	{
		driver.findElementByXPath("//input[@name='id']").sendKeys(leadid);
		return this;
	}
	
	public FindLeadsPage clickFindLeadsinFindLeadsPage()
	{
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		return this;
	}

	public String captureFirstResultingLeadName() throws InterruptedException
	{
		Thread.sleep(2000);
		String fName=driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
		System.out.println("First Name in find leadspage is"+fName);
		return fName;
	}
	public ViewLeadPage clickFirstResultingLeadName() throws InterruptedException
	{
		Thread.sleep(2000);
		String fName=driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
		System.out.println("First Name in find leadspage is"+fName);
		
		//Click First Resulting lead
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").click();
		
		return new ViewLeadPage();
		
	}
	
	public ViewLeadPage clickFirstResultingLeadId() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		return new ViewLeadPage();
	}
	public FindLeadsPage clickPhoneTab()
	{
		driver.findElementByXPath("//span[text()='Phone']").click();
		return this;
	}
	public FindLeadsPage clickEmailTab()
	{
		
		driver.findElementByXPath("//span[text()='Email']").click();
		return this;
	}
	public FindLeadsPage enterEmail()
	{
		driver.findElementByName("emailAddress").sendKeys("xyz@gmail.com");
		return this;
	}
	public FindLeadsPage enterPhoneDeatils()
	{
		driver.findElementByXPath("//input[@name='phoneCountryCode']").clear();
		driver.findElementByXPath("//input[@name='phoneCountryCode']").sendKeys("1");
		driver.findElementByXPath("//input[@name='phoneAreaCode']").sendKeys("");
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys("8870415213");
		return this;
	}
	
	public FindLeadsPage enterCapturedLeadIdInFindLeads(String leadID)
	{
		driver.findElementByXPath("//input[@name='id']").sendKeys(leadID);
		return this;
		
	}
	public FindLeadsPage verifyNoRecordsFoundInFindLeadsPage()
	{
		String NoRecords=driver.findElementByClassName("x-paging-info").getText();
		System.out.println(NoRecords);
		if(NoRecords.equals("No records to display"))
				{
			System.out.println("There are no records in the table");
				}
		else
		{
			System.out.println("Record still exists");
				}
		return this;
	}
}
