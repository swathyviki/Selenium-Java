package pages;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{

	public HomePage verifyLogin()
	{
		String text = driver.findElementByTagName("h2").getText();
		if(text.contains("Demo"))
		{
			System.out.println("Login successful");
		}
		else
		{
			System.out.println("Login failed");
		}
		return this;
	}
	public MyHomePage clickCrmSfa()
	{
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage();
	}
}
