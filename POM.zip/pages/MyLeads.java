package pages;

import base.ProjectSpecificMethods;

public class MyLeads extends ProjectSpecificMethods{

	public CreateLeadPage clickCreateLead()
	{
		driver.findElementByLinkText("Create Lead").click();
		return new CreateLeadPage();
	}
	public FindLeadsPage clickFindLeadsinMyLeadsPage()
	{
		driver.findElementByLinkText("Find Leads").click();
		return new FindLeadsPage();
	}
	public MergeLeadsPage clickMergeLeadInMyLeadsPage()
	{
		driver.findElementByLinkText("Merge Leads").click();
		return new MergeLeadsPage();
	}
}
