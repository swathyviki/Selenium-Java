package pages;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{
	private static final ViewLeadPage leadID = null;
	public ViewLeadPage verifyFirstName()
	{
		String ViewLeadCNAme=driver.findElementById("viewLead_firstName_sp").getText();
		if (ViewLeadCNAme.equals("Swathy"))
		{
			System.out.println("Lead is created");
			
		}
		else
		{
			System.out.println("Lead is created");
			
		}
		return this;
	}
	public MyLeads clickDeleteinViewLeadPage()
	{
		driver.findElementByLinkText("Delete").click();
		return new MyLeads();
	}
	public DuplicateLeadPage clickDuplicateLeadinViewLeadPage()
	{
		driver.findElementByLinkText("Duplicate Lead").click();
		return new DuplicateLeadPage();
	}
	public EditLeadPage clickEdit()
	{
		driver.findElementByLinkText("Edit").click();
		return new EditLeadPage();
				
	}
	public ViewLeadPage verifyCompanyNameUpdated()
	{
		String UCompanyName = driver.findElementById("viewLead_companyName_sp").getText();
		if(UCompanyName.contains("ADP"))
		{
			System.out.println("Company name updated succesfully as ADP");
		}
		else
		{
			System.out.println("Company name not updated succesfully ");
		}	
		return this;
	}
	public static String captureLeadIdFromCompanyNameInViewLeadsPage()
	{
		String leadID= driver.findElementById("viewLead_companyName_sp").getText();
		String[] leadarray=leadID.split(" ");
		
		
			System.out.println("Lead name with id in ()is "+leadarray[1]);
		
		leadID = leadarray[1].replaceAll("\\p{P}","");
		
		System.out.println("Lead id after removing () is"+leadID);
		return leadID;
	}
	public ViewLeadPage verifyCapturedandDuplicateLeadaresame(String fname)
	{
		String duplicatName=driver.findElementById("viewLead_firstName_sp").getText();
		System.out.println("Duplicate name is"+duplicatName);
		if(fname.equals(duplicatName))
		{
			System.out.println("duplicate lead name is same as captured lead");
		}
			else
			{
				System.out.println("duplicate lead name is not same as captured lead");
			}
		return this;
	}
	public FindLeadsPage clickFindLeadsFromiewLeadsPage()
	{
		driver.findElementByLinkText("Find Leads").click();
		return new FindLeadsPage();
	}
	
}
