package tescases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC005_MergeLead extends ProjectSpecificMethods {
	@Test
	public void tc005_editLead()throws InterruptedException
	{
	LoginPage obj=new LoginPage();
	 obj.enterUserName()
	 .enterPassword()
	 .clickLogin()
	 .verifyLogin()
	 .clickCrmSfa()
	 .clickLeads()
	 .clickMergeLeadInMyLeadsPage()
	 .clickOnIconNearFromLead()
	 .enterLeadIdinFindLeadsWindow("10224")
	 .clickFindLeadsButtonInFindLeadsWindow()
	 .clickFirstResultingLeadIdInFindLeadsWindow()
	 .clickOnIconNearToLead()
	 .enterLeadIdinFindLeadsWindow("10550")
	 .clickFindLeadsButtonInFindLeadsWindow()
	 .clickFirstResultingLeadIdInFindLeadsWindow()
	 .clickMergeInMergeLeadsPage()
	 .clickFindLeadsFromiewLeadsPage()
	 .enterLeadIdinFindLeadsPage("10224")
	 .clickFindLeadsinFindLeadsPage()
	 .verifyNoRecordsFoundInFindLeadsPage();
	}
	 
	 
	 
	 
}
