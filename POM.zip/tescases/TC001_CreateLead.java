package tescases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;


public class TC001_CreateLead extends ProjectSpecificMethods{
	@BeforeTest
	public void setData()
	{
		filename="createLead";
	}
	@Test(dataProvider="getData")
	public void tc001_createLead(String cname,String fname,String lname)
	{
		new LoginPage()
		 .enterUserName()
		 .enterPassword()
		 .clickLogin()
		 .verifyLogin()
		 .clickCrmSfa()
		 .clickLeads()
		 .clickCreateLead()
		 .enterCompanyName(cname)
		 .enterFirstName(fname)
		 .enterLastName(lname)
		 .clickCreateLead()
		 .verifyFirstName();
		 
	}
 
}
