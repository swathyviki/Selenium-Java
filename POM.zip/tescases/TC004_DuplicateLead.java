package tescases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.FindLeadsPage;
import pages.LoginPage;

public class TC004_DuplicateLead extends ProjectSpecificMethods {
	@Test
	public void tc004_duplicateLead()throws InterruptedException
	{
	LoginPage obj=new LoginPage();
	 obj.enterUserName()
	 .enterPassword()
	 .clickLogin()
	 .verifyLogin()
	 .clickCrmSfa()
	 .clickLeads()
	 .clickFindLeadsinMyLeadsPage()
	 .clickEmailTab()
	 .enterEmail()
	 .clickFindLeadsinFindLeadsPage();
	 FindLeadsPage fbj=new FindLeadsPage();
	 String fname=fbj.captureFirstResultingLeadName();
	 
	 fbj.clickFirstResultingLeadName()
	 .clickDuplicateLeadinViewLeadPage()
	 .verifyPageTitleidDuplicateLead()
	 .clickCreateLeadinDuplicateLeadPage()
	 .verifyCapturedandDuplicateLeadaresame(fname);
	}
}
