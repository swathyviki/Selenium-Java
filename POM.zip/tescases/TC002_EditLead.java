package tescases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC002_EditLead extends ProjectSpecificMethods{
	@Test
	public void tc002_editLead()throws InterruptedException
	{
	new LoginPage()
	 .enterUserName()
	 .enterPassword()
	 .clickLogin()
	 .verifyLogin()
	 .clickCrmSfa()
	 .clickLeads()
	 .clickFindLeadsinMyLeadsPage()
	 .enterFirstNameinFindLeadsPage()
	 .clickFindLeadsinFindLeadsPage()
	 .clickFirstResultingLeadName()
	 .clickEdit()
	 .changeCompanyName()
	 .clickUpdate()
	 .verifyCompanyNameUpdated();
	}

}
