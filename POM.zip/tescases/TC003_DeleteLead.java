package tescases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.ViewLeadPage;

public class TC003_DeleteLead extends ProjectSpecificMethods{
	@Test
	public void tc003_deleteLead()throws InterruptedException
	{
		
		LoginPage obj=new LoginPage();
		ViewLeadPage vbj=new ViewLeadPage();
		 obj.enterUserName()
		 .enterPassword()
		 .clickLogin()
		 .verifyLogin()
		 .clickCrmSfa()
		 .clickLeads()
		 .clickFindLeadsinMyLeadsPage()
		 .clickPhoneTab()
		 .enterPhoneDeatils()
		 .clickFindLeadsinFindLeadsPage()
		 .clickFirstResultingLeadName();
		String leadid=ViewLeadPage.captureLeadIdFromCompanyNameInViewLeadsPage();
		vbj.clickDeleteinViewLeadPage()
		 .clickFindLeadsinMyLeadsPage()		
		 .enterCapturedLeadIdInFindLeads(leadid)
		 .clickFindLeadsinFindLeadsPage()
		 .verifyNoRecordsFoundInFindLeadsPage();
		 
		 
		 
	}
	

}
