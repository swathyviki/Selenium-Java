package steps;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC004_DuplicateLead extends ProjectSpecificMethods{
	
	@Given("Click on Email tab in Find Leads Page")
	public void clickOnEmailTabInFindLeadsPage() {
		driver.findElementByXPath("//span[text()='Email']").click();
	}
	@Given("Enter email adrress")
	public void enterEmailAdrress() {
		driver.findElementByName("emailAddress").sendKeys("siddhu@gmail.com");
	}
	

	@Given("Click on Find Leads button in Find Leads Page")
	public void clickOnFindLeadsButtonInFindLeadsPage() {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
	}

	@Given("Capture name of first resuting lead as leadname")
	public static String capture_name_of_first_resuting_lead_as_leadname() throws InterruptedException {
		Thread.sleep(2000);
		//System.out.println(driver.findElementByXPath(("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]")).getText());
		leadname= driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
		
		System.out.println(leadname);
		return leadname;
		
	}
	

	@When("Click on Duplicate Lead")
	public void clickOnDuplicateLead() {
		driver.findElementByLinkText("Duplicate Lead").click();
		
	}

	@When("Verify title of the page is Duplicate Lead")
	public void verifyTitleOfThePageIsDuplicateLead() {
		String title = driver.findElementByXPath("//div[@class='x-panel-header sectionHeaderTitle']").getText();
		System.out.println("verifying duplcate lead title is present"+title);
	}

	@When("Click Create Lead in Duplicate Lead Page")
	public void clickCreateLeadInDuplicateLeadPage() {
		driver.findElementByClassName("smallSubmit").click();
		
	}
	
	@Then("Verify captured name and duplicate are same")
	public void verify_captured_name_and_duplicate_are_same() throws InterruptedException {
		String duplicatName=driver.findElementById("viewLead_firstName_sp").getText();
		System.out.println("Duplicate name and leadname is"+duplicatName+leadname);
		Thread.sleep(1000);
		if(leadname.equals(duplicatName))
		{
			System.out.println(duplicatName+" duplicate lead name is same as captured lead"+leadname);
		}
		else
		{
				System.out.println(duplicatName+"duplicate lead name is not same as captured lead"+leadname);
		}
					}

	

}
