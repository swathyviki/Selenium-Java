package steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC005_MergeLead extends ProjectSpecificMethods{
	@Then("Click on Merge Leads")
	public void clickOnMergeLeads() {
		driver.findElementByLinkText("Merge Leads").click();
		}

	@Then("Click on icon near From Lead and Move to new window")
	public void clickOnIconNearFromLeadandmoveToNewWindow() {
		driver.findElementByXPath("//img[@src='/images/fieldlookup.gif']").click();
		Set<String> wdw1=driver.getWindowHandles();
		List<String> lstwindowHandles= new ArrayList<String>(wdw1);
		String secondwindow=lstwindowHandles.get(1);
		driver.switchTo().window(secondwindow);
	}

	

	@Then("Enter Lead Id")
	public void enterLeadId() {
		driver.findElementByXPath("//input[@type='text']").sendKeys("10002");
	}

	@Then("Click Find Leads button")
	public void clickFindLeadsButton() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@class='x-btn-text']").click();
	}

	@Then("Click on the first resulting lead id")
	public void clickOnTheFirstResultingLeadId() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
	}

	@Then("Switch back to primary window")
	public void switchBackToPrimaryWindow() {
		Set<String> wdw1=driver.getWindowHandles();
		List<String> lstwindowHandles= new ArrayList<String>(wdw1);
		driver.switchTo().window(lstwindowHandles.get(0));
	}

	@Then("Click on icon near To Lead and Move to New window")
	public void clickOnIconNearToLeadandmoveToNewWindow() {
		driver.findElementByXPath("(//img[@src='/images/fieldlookup.gif'])[2]").click();
		Set<String> wdw2=driver.getWindowHandles();
		List<String> lstwindowHandles1= new ArrayList<String>(wdw2);
		String secondwindow1=lstwindowHandles1.get(1);
		driver.switchTo().window(secondwindow1);
	}

	
	@Then("Enter Lead Id for To Lead")
	public void enterLeadIdforToLead() {
		driver.findElementByXPath("//input[@type='text']").sendKeys("10003");
	}

	@Then("Click Find Leads button for To Lead")
	public void clickFindLeadsButtonForToLead() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@class='x-btn-text']").click();
	}

	@Then("Click on the first resulting lead id for To Lead")
	public void clickOnTheFirstResultingLeadIdForToLead() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		Set<String> wdw1=driver.getWindowHandles();
		List<String> lstwindowHandles= new ArrayList<String>(wdw1);
		driver.switchTo().window(lstwindowHandles.get(0));
	}

	
	@Then("Click Merge")
	public void clickMerge() {
		//Click Merge
				driver.findElementByLinkText("Merge").click();
	}
	@Then("accept the alert")
	public void acceptTheAlert() {
		//accept alert
		driver.switchTo().alert().accept();
	}
	@Then("Click on Find Leads and enter From Lead ID")
	public void clickOnFindLeadsAndEnterFromLeadId()
	{
				
				//click the find leads link
				driver.findElementByLinkText("Find Leads").click();
				//Enter From Lead ID
				driver.findElementByXPath("//input[@name='id']").sendKeys("10002");
	}
	
				
				

	

	@When("Click on Find leads button")
	public void enterFromLeadIdAndClickOnFindLeadsButton() {
		//Click Find Leads button
		driver.findElementByXPath("//button[text()='Find Leads']").click();
	}

	@Then("Verify message No records to display")
	public void verifyMessageNoRecordsToDisplay() throws InterruptedException {
		//Verify message no records to display
		String NoRecords=driver.findElementByClassName("x-paging-info").getText();
		System.out.println(NoRecords);
		Thread.sleep(2000);
		if(NoRecords.equals("No records to display"))
				{
			System.out.println("There are no records in the table");
				}
		else
		{
			System.out.println("Record still exists");
				}
}
}


