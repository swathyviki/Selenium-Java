package steps;

import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC002_EditLead extends ProjectSpecificMethods {
	@Then("Click on Leads")
	public void click_on_Leads() {
		driver.findElementByLinkText("Leads").click();
	}


	@Given("Click Find Leads")
	public void click_Find_Leads() {
		driver.findElementByLinkText("Find Leads").click();
	}
	@Given("Enter the first name")
	public void enterTheFirstName() {
		driver.findElementByXPath("(//div[@class='x-form-element']/input[@name='firstName'])[3]").sendKeys("Swathy");
	}
	@Given("Click on Find Leads button")
	public void clickOnFindLeadsButton() {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
	}
	@Given("capture name of first resuting lead")
	public void captureNameOfFirstResutingLead() throws InterruptedException {
		Thread.sleep(2000);
		String fName=driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
		System.out.println("First Name in find leadspage is"+fName);
	}
	@When("Click First Resulting lead")
	public void clickFirstResultingLead() {
		//Click First Resulting lead
				driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").click();
	}
	@When("Click Edit")
	public void clickEdit() {
		driver.findElementByLinkText("Edit").click();

	}
	@When("Change Company name")
	public void changeCompanyName() {
		driver.findElementById("updateLeadForm_companyName").clear();
		driver.findElementById("updateLeadForm_companyName").sendKeys("TCS");
	}
	@When("click on Update")
	public void clickOnUpdate() {
		driver.findElementByXPath("//input[@value='Update']").click();
	}
	@Then("check the company name is updated")
	public void checkTheCompanyNameIsUpdated() {
		String UCompanyName = driver.findElementById("viewLead_companyName_sp").getText();
		if(UCompanyName.contains("TCS"))
		{
			System.out.println("Company name updated succesfully as TCS");
		}
		else
		{
			System.out.println("Company name not updated succesfully ");
		}	
	}
	

}
