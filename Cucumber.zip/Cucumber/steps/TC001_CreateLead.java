package steps;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC001_CreateLead extends ProjectSpecificMethods{
	

	@Given("Enter the username as DemoSalesManager")
	public void enterTheUsername() {
		WebElement username = driver.findElementById("username");
		username.sendKeys("DemoSalesManager");
	}
	

	@Given("Enter the password as crmsfa")
	public void enterThePassword() {
		WebElement password = driver.findElementById("password");
		password.sendKeys("crmsfa");
	}

	@When("Click on Login button")
	public void clickOnLoginButton() {
		driver.findElementByClassName("decorativeSubmit").click();
	}
	@Then("Verify Login is succesful")
	public void verifyLoginIsSuccesful() {
	    if(driver.findElementByLinkText("CRM/SFA").isDisplayed())
	    {
	    	System.out.println("succesz");
	    }
	}

	

	@Given("Click CRMSFA")
	public void clickCRMSFA() {
		driver.findElementByLinkText("CRM/SFA").click();
	}

	@Then("Verify Lead page is displayed")
	public void verifyLeadPageIsDisplayed() {
		WebElement LeadPage = driver.findElementByLinkText("Leads");
		if(LeadPage.isDisplayed())
		{
			System.out.println("Lead page is displayed");
		}
		else
		{
			System.out.println("Lead page is not displayed");
		}
	}

	@Given("Click Create Lead")
	public void clickCreateLead() {
		driver.findElementByLinkText("Create Lead").click();
	}

	@Given("Enter companyname as (.*)")
	public void enterCompanyname(String cname) {
		// Enter Company Name
				driver.findElementById("createLeadForm_companyName").sendKeys(cname);
	}

	@Given("Enter first name as (.*)")
	public void enterFirstName(String fname) {

		// Enter First Name
		driver.findElementById("createLeadForm_firstName").sendKeys(fname);
		
	}

	@Given("Enter last name as (.*)")
	public void enterLastName(String lname) {
	
		// Enter Last Name
		driver.findElementById("createLeadForm_lastName").sendKeys(lname);
	}

	

	@When("Click on Create Lead button")
	public void clickOnCreateLeadButton() {
		
		driver.findElementByClassName("smallSubmit").click();
	}

	@Then("Verify Lead is created")
	public void verifyLeadIsCreated() {
	    // Write code here that turns the phrase above into concrete actions
		WebElement submit = driver.findElementByClassName("smallSubmit");
		if(submit.isDisplayed())
		{
			System.out.println("Created");
		}
	    //throw new cucumber.api.PendingException();
	}
	


}
