package steps;

import base.ProjectSpecificMethods;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class LearnHooks extends ProjectSpecificMethods{
	@Before
	public void preScenario(Scenario sc)
	{	
		launchBrowser();
	}
@After
public void postScenario(Scenario sc)
{
	closeBrowser();
}

}
