package steps;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC003_DeleteLead extends ProjectSpecificMethods {
	public String leadID;
	@Given("Click on Phone tab in Find Leads page")
	public void click_on_Phone_tab_in_Find_Leads_page() {
		driver.findElementByXPath("//span[text()='Phone']").click();
	}

	@Given("Enter the phone number")
	public void enter_the_phone_number() {
		driver.findElementByXPath("//input[@name='phoneCountryCode']").clear();
		driver.findElementByXPath("//input[@name='phoneCountryCode']").sendKeys("+91");
		driver.findElementByXPath("//input[@name='phoneAreaCode']").sendKeys("044");
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys("326121");
	}

	@Given("Click on find leads button in Find Leads page")
	public void click_on_find_leads_button_in_Find_Leads_page() {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
	}

	@Given("Extract  Lead id from company name in View Leads page")
	public String extract_Lead_id_from_company_name_in_View_Leads_page() throws InterruptedException {
	    Thread.sleep(2000);
	    String leadFName =driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").getText();
		System.out.println("leadID is"+leadFName);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a)[1]").click();
		
		String leadID= driver.findElementById("viewLead_companyName_sp").getText();
		String[] leadarray=leadID.split(" ");
		
		
			System.out.println("Lead name with id in ()is "+leadarray[1]);
		
		leadID = leadarray[1].replaceAll("\\p{P}","");
		
		System.out.println("Lead id after removing () is"+leadID);
		return leadID;
	}

	@When("Click on delete")
	public void click_on_delete() {
		driver.findElementByLinkText("Delete").click();
	}

	@When("Click on Find Leads")
	public void click_on_Find_Leads() throws InterruptedException {
		Thread.sleep(2000);
		//Click on Find Leads
		driver.findElementByLinkText("Find Leads").click();
	}
	@When("Enter the captured lead id as (.*)")
	public void enter_the_captured_lead_id_as(String leadID) {
		driver.findElementByXPath("//input[@name='id']").sendKeys(leadID);
	}

	
	@Then("Verify message no records to display in the lead list")
	public void verify_message_no_records_to_display_in_the_lead_list() {
		String NoRecords=driver.findElementByClassName("x-paging-info").getText();
		System.out.println(NoRecords);
		if(NoRecords.equals("No records to display"))
				{
			System.out.println("There are no records in the table");
				}
		else
		{
			System.out.println("Record still exists");
				}
	}


}
